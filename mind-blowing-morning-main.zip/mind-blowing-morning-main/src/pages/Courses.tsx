export default function Courses() {
  return <p>Courses</p>;
}
